--------------------------------------------------------------------------------
                Solution explanation for the workshopD
--------------------------------------------------------------------------------

1. Introduction:
~~~~~~~~~~~~~~~
    This document aim to explain solution for the requirement in workshopD 
    Modify file the source code of the copy file program to resolve four problems described in the file "D.pf"

    Material for this presentation:
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    cp1old.c    : The original source code of the copy program
    cp1.c       : The source code which already modify to resolve the problems.
    Makefile    : The make file used for compile cp1old.c and cp1.c to executable file.
    
    How to build program:
    ~~~~~~~~~~~~~~~~~~~~
    Simply run the make command under WorkShopD.
    $ make
    After running make command, two executable files will be output:
    cp1old      : The binary (executable file) which compiled from cp1old.c
    cp1         : The binary (executable file) which compiled from the source code cp1.c

2. Detail about each problem:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    2.1. Firstly problem: copy file to itself.
        When copy a file onto itself the content of the file will be empty.
        i.e: $ ./cp1old input input -> the content of the input file will be empty.

        Expected behaviour : 
        program should notify to the user that 'destination file' and the 'source file' are the same
        then do nothing.

    Solution: 
        Refer to the source code file: cp1.c -> line 40 to line 54
        Check the source file and destination file (compare two file).

        if could not compare -> notify the error message "can not compare two file ..."
        Then free memory and exit program with exit code is '1'.

        else if two file is the same -> notify the message "'source file' and 'destination file' is the same
        Then free memory and exit program with exit code is '1'.

        else : Do continue next step of copy operation

        -> Refer to section "3.1. is_same_file" of this document for detail implementation
        of the function compare two file.
	How to test:
		1. create test.txt
		$ ls -l > test.txt
		$ ./cp1 test.txt test.txt
		output: 
		----
		./cp1: 'test.txt' and 'test.txt' are the same file
		----


    2.2. Secondly problem: keep same permission when copy a file.
        When copy a file the file permission of the destination file not same
        with the permission of the source file.
        i.e: 
        $ ./cp1old cp1 cp2
        $ ls -l cp1 cp2
        ----
        -rwxr-xr-x 1 owner group 9153 May 13 14:24 cp1
        -rw-r--r-- 1 owner group 9153 May 13 14:31 cp2
        ---
        -> Permission of two file are not same, there is no executable permission on the file cp2.
        -> We must modify the source code to solve this problem by copy file permission
        of the source file to the destination file.

    Solution:
        Refer to the cp1.c : from line 92 -> line 100.
        After copy content of the source file to the destination file
        also copy file permission from source file to the destination file.
        This function is implemented in the function : int sync_file_permission(char *src, char *dest);
        Refer to the section 3.2 of this document to get detail of implementation of this function.
	
	How to test
		$ ./cp1 cp1 cp3
        $ ls -l cp1 cp2 cp3
		output:
		----
		-rwxr-xr-x 1 owner group 8928 May 13 20:44 cp1
		-rw-r--r-- 1 owner group 8928 May 13 20:57 cp2
		-rwxr-xr-x 1 owner group 8928 May 13 20:58 cp3
		----


    2.3. Thirdly problem: Second argument is directory.
        Real copy programs allow the second argument to be a directory,
        While the cp1old not allow it.
        i.e:
        -----
        $ mkdir test
        $ ./cp1old D.pdf test/
        $ Error: Cannot creat test/: Is a directory
        -----
        -> We must modify the source code of cp1old.c to allow it.
        When the second argument is an directory, create the destination file with the
        same name of the source file under that directory and copy content of source file to
        destination file.

    Solution: 
        Refer to the cp1.c : from line 33 to line 38.
        In case the second parameter is a directory, create the destination file with the same name
        of the input file under that directory then copy content of the input file to the destination file.
        This behaviour is implemented by adding the function "dest_file_name"
        Refer to the section 3.3 of this document to get detail about implementation of this function.
	
	How to test:
		$ mkdir testdir
		$ ./cp1 cp1 testdir
		$ ls -l testdir/
		output
		---
		$ total 12
		-rwxr-xr-x 1 owner group 8928 May 13 21:07 cp1
		---

    2.4. Fourthly problem: copy file if the destination file already existed.
        i.e:
        ---
        1. Create two files test.txt and test1.txt
        $ ls -l > test.txt
        $ ls -la > test1.txt
        1. copy file test.txt to test1.txt
        $ ./cp1old test.txt test1.txt
        -> The copy operation is execute normally, the content of the destination
        file "test1.txt" will be replace by the content of the source file "test.txt"
        ---
        -> We must modify the source code to abort the copy operation in case the destination file 
        already existed.

    Solution:
        Refer to cp1.c -> line 56 -> line 64.
        Check if the destination file, 
        In case it's existed, notify the message to user and abort copy operation
        In case not existed, continue other operation to copy file.
        This behaviour is implemented by adding the function "bool is_file_existed(char *filename)"
        Refer to section : 3.4 for detail implementation of this function.
	
	How to test:
		$ ./cp1 cp1 cp4
		$ ./cp1 cp1 cp4
		output:
		----
		copy abort: 'cp4' already existed
		----

3. Detail explanation for each function added to the cp1.c
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    3.1. is_same_file : Check if two file is the same file or not.
        prototype: int is_same_file(char *src, char *dest);
        param : char * src  : pointer to file name or file name with full path of the source file
        param : char * dest : pointer file name or file name with full path of the destination file
        return: return -1 if could not compare, 'SAME' if src and dest is the same file and 'NOT_SAME' if not.
        Note: 'SAME' and 'NOT_SAME' is defined by : enum {SAME = 0, NOT_SAME};

        Steps of implementation:
            1. open source file in read-only mode by the system call 'open' with O_RDONLY flag.
            2. get file status of the source file by the system call 
            'fstat' with the file descriptor of source file.
            3. open the destination file by 'open' and get status of destination file by 'fstat'
                At this steps: if the destination file not existed, 
                call 'stat' function to get file status.
            4. compare: device no and i-node number of two file.
            5. return 'SAME' if two parameter is same and 'NOT_SAME' if one of them not same.

    3.2. sync_file_permission : Copy file permission from source file to destination file.
        prototype : int sync_file_permission(char *src, char *dest);
        parameter : char *src pointer to the file path of the source file
        parameter : char *dest pointer to the file path of the destination file
        return    : return 0 on success and -1 on error.

        Steps of implementation:
            1. get file status of the source file.
            2. change permission of the destination same file as permission of source file
               chmod(dest, s_stat.st_mode)
            3. return 0 if chmod is success and -1 of chmod is failed.

    3.3. dest_file_name : Create destination file name from src and dest input file.
        prototype : char *dest_file_name(char * src, char* dest);
        parameter : char * src pointer to the file name or full path of the source file.
        parameter : char * dest pointer to the file name or full path of the destination file.
        return    : return pointer to the destination file name, the destination file name is create
        by the rule: 
            if dest is not directory, just simply create file name same as "dest"
            if dest is an directory, create destination file with the same name of src file
            under the that directory (append the string "src" to the "dest" 
            after append '/' character.
        Note: Space of memory for store new file name is allocated dynamically.
            Then it's required to free memory after use new file name.

        Steps of implementation:
            1. Get destination file status.
            2. Check the destination file to confirm it's directory or not.
            3. In case it's not directory, simply create destination file name as the user input.
            4. In case it's a directory, create the destination file name same as source file
               under the destination directory.
            Note: 
            In case user input '/' character at the end of destination directory,
            simply append the src string to the destination string.
            In case user dit not input '/' character at the end of destination directory,
            append the character '/' then append src string to the destination string.

    3.4. is_file_existed : Check the file name to make sure the file existed or not.
        prototype : bool is_file_existed(char *filename)
        parameter : char *filename : filename or filepath of the file to be checked.
        return    : return true if the file existed and false if not existed.

        Steps of implementation: 
            1. Try to access the file with the name 'filename' by call system call 'access'.
            2. return true if can access.
            3. return false if can not access.

    3.5. free_mem : wrapper of the fee memory function "free" free allocated memory after used.
        prototype : void free_mem(void *ptr)
        parameter : void *ptr pointer to the allocated memory need to be free 
        return : None.
        
        Step of implementation
            1. check the input pointer to make sure it's not NULL.
            2. free memory by calling system call 'free'.

4. Conclusion
    This is just simply implementation to satisfy the requirement of the workshpD
    which described on the D.pdf. Actually the program included many improvement point.
    so please give some comment if you have.
